/***************************************************************
 * Name:      wxPanelApp.cpp
 * Purpose:   Code for Application Class
 * Author:    pavel (pavelkanazirev@gmail.com)
 * Created:   2018-07-21
 * Copyright: pavel ()
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "wxPanelApp.h"
#include "wxPanelMain.h"

IMPLEMENT_APP(wxPanelApp);

bool wxPanelApp::OnInit()
{
    VBusGen* frame = new VBusGen(0L);

    frame->Show();

    return true;
}
