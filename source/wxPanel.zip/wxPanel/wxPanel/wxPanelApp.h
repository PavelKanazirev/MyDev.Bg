/***************************************************************
 * Name:      wxPanelApp.h
 * Purpose:   Defines Application Class
 * Author:    pavel (pavelkanazirev@gmail.com)
 * Created:   2018-07-21
 * Copyright: pavel ()
 * License:
 **************************************************************/

#ifndef WXPANELAPP_H
#define WXPANELAPP_H

#include <wx/app.h>

class wxPanelApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // WXPANELAPP_H
