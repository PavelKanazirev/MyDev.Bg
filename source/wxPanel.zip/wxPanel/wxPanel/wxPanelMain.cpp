///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Jul 21 2018)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "wxPanelMain.h"

///////////////////////////////////////////////////////////////////////////

VBusGen::VBusGen( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxFlexGridSizer* fgPanelSizer;
	fgPanelSizer = new wxFlexGridSizer( 2, 1, 0, 0 );
	fgPanelSizer->SetFlexibleDirection( wxBOTH );
	fgPanelSizer->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_SPECIFIED );

	wxStaticBoxSizer* sbLabelRowSizer;
	sbLabelRowSizer = new wxStaticBoxSizer( new wxStaticBox( this, wxID_ANY, wxT("Column name") ), wxVERTICAL );

	wxFlexGridSizer* fgSizer3;
	fgSizer3 = new wxFlexGridSizer( 1, 5, 0, 0 );
	fgSizer3->SetFlexibleDirection( wxBOTH );
	fgSizer3->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_SPECIFIED );

	m_staticText1 = new wxStaticText( sbLabelRowSizer->GetStaticBox(), wxID_ANY, wxT("Provider"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText1->Wrap( -1 );
	fgSizer3->Add( m_staticText1, 0, wxALL, 5 );

	m_staticText2 = new wxStaticText( sbLabelRowSizer->GetStaticBox(), wxID_ANY, wxT("Port"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText2->Wrap( -1 );
	fgSizer3->Add( m_staticText2, 0, wxALL, 5 );

	m_staticText3 = new wxStaticText( sbLabelRowSizer->GetStaticBox(), wxID_ANY, wxT("Interface"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText3->Wrap( -1 );
	fgSizer3->Add( m_staticText3, 0, wxALL, 5 );

	m_staticText4 = new wxStaticText( sbLabelRowSizer->GetStaticBox(), wxID_ANY, wxT("Port"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText4->Wrap( -1 );
	fgSizer3->Add( m_staticText4, 0, wxALL, 5 );

	m_staticText5 = new wxStaticText( sbLabelRowSizer->GetStaticBox(), wxID_ANY, wxT("Receiver"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText5->Wrap( -1 );
	fgSizer3->Add( m_staticText5, 0, wxALL, 5 );


	sbLabelRowSizer->Add( fgSizer3, 1, wxEXPAND, 5 );


	fgPanelSizer->Add( sbLabelRowSizer, 1, wxEXPAND, 5 );

	wxStaticBoxSizer* sbTextAreaSizer;
	sbTextAreaSizer = new wxStaticBoxSizer( new wxStaticBox( this, wxID_ANY, wxT("Data") ), wxVERTICAL );

	wxFlexGridSizer* fgSizer2;
	fgSizer2 = new wxFlexGridSizer( 1, 5, 0, 0 );
	fgSizer2->SetFlexibleDirection( wxBOTH );
	fgSizer2->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_SPECIFIED );

	m_listBox1 = new wxListBox( sbTextAreaSizer->GetStaticBox(), wxID_ANY, wxDefaultPosition, wxDefaultSize, 0, NULL, 0 );
	fgSizer2->Add( m_listBox1, 0, wxALL, 5 );

	m_listBox2 = new wxListBox( sbTextAreaSizer->GetStaticBox(), wxID_ANY, wxDefaultPosition, wxDefaultSize, 0, NULL, 0 );
	fgSizer2->Add( m_listBox2, 0, wxALL, 5 );

	m_listBox3 = new wxListBox( sbTextAreaSizer->GetStaticBox(), wxID_ANY, wxDefaultPosition, wxDefaultSize, 0, NULL, 0 );
	fgSizer2->Add( m_listBox3, 0, wxALL, 5 );

	m_listBox5 = new wxListBox( sbTextAreaSizer->GetStaticBox(), wxID_ANY, wxDefaultPosition, wxDefaultSize, 0, NULL, 0 );
	fgSizer2->Add( m_listBox5, 0, wxALL, 5 );

	m_listBox6 = new wxListBox( sbTextAreaSizer->GetStaticBox(), wxID_ANY, wxDefaultPosition, wxDefaultSize, 0, NULL, 0 );
	fgSizer2->Add( m_listBox6, 0, wxALL, 5 );


	sbTextAreaSizer->Add( fgSizer2, 1, wxEXPAND, 5 );


	fgPanelSizer->Add( sbTextAreaSizer, 1, wxEXPAND, 5 );


	this->SetSizer( fgPanelSizer );
	this->Layout();

	this->Centre( wxBOTH );
}

VBusGen::~VBusGen()
{
}
